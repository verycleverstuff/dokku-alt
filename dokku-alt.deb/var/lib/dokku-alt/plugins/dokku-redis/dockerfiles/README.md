Dockerfiles
-----------

    docker build -t dokku/redis github.com/luxifer/dokku-redis-dockerfiles
