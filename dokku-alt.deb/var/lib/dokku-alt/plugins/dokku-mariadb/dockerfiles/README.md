Dockerfiles
-----------

```
docker build -t dokku/mariadb github.com/Kloadut/dokku-md-dockerfiles
```
